 <footer class="footer">
            <div class="container-fluid">
               
                <div class="copyright pull-right">
                    &copy; copyright  <script>document.write(new Date().getFullYear())</script> all rights reserved by <a href="http://www.gbdevelopers.net">GB</a>
                </div>
            </div>
        </footer>