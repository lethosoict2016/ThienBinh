 <ul class="nav">
    <li class="active">
        <a href="<?php echo base_url('userpanel');?>">
            <i class="ti-panel"></i>
            <p>My Profile</p>
        </a>
    </li>
	 <li>
        <a href="<?php echo base_url('userpanel/availabilty');?>">
            <i class="ti-view-list-alt"></i>
            <p>Check Medicines Availability</p>
        </a>
    </li>
     <li>
        <a href="<?php echo base_url('userpanel/prescription');?>">
            <i class="ti-view-list-alt"></i>
            <p>Upload Prescription</p>	
        </a>
    </li>
	<li>
        <a href="<?php echo base_url('userpanel/order_history');?>">
            <i class="ti-user"></i>
            <p>My prescriptions</p>
        </a>
    </li>
	<li>
        <a href="<?php echo base_url('useremail/');?>">
            <i class="ti-user"></i>
            <p>Contact Pharmacy</p>
        </a>
    </li>	
</ul>