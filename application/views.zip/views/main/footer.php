  <div class="row">
  		<div class="col-md-12">
		  <footer class="main-footer  text-center">
		    <strong>
				© Copyright Medix v3.0 2018- 2020 developed by SpantikLab. All Rights Reserved.
			</strong>
		  </footer> 
  		</div>
  </div>